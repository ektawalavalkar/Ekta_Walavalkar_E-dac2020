import java.util.*;
public class Que1 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		int vowels=0, cons=0, num=0,others=0;
		
		for (int i = 0; i < s.length(); i++)
		{
			
		char ch = s.charAt(i); 
		
		if((ch >= 'a' && ch <='z') || (ch>= 'A' && ch<='Z'))
		{
		ch = Character.toLowerCase(ch);
		if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
		{
			vowels++;
		}
		else
		{
				cons++;
		}
		}
		
		else if(ch>='0' && ch<='9')
			num++;
		else
			others++;
			
		}
		
		    System.out.println("Vowels: " + vowels); 
	        System.out.println("Consonant: " + cons); 
	        System.out.println("Digit: " + num); 
	        System.out.println("Special Character: " +others); 
				
	}

}
