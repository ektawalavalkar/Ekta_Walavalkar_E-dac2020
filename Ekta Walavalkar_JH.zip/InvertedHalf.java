
public class InvertedHalf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int j = 0; j <= 6; j++) 
		{
			for (int i=6; i>= j; i--) 
			{
			
				System.out.print("*");
			}
				
			
			System.out.println();                     
		}
	}

}
