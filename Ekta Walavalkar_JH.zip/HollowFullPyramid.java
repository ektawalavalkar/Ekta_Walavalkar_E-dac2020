public class HollowFullPyramid {
	public static void main(String args[]) {

		for (int j = 1; j <= 6; j++)// row
		{
			for (int i = 6; i >= j; i--)// col
			{
				System.out.print(" ");
			}
			if(j<3||j>5)
			{
					for (int m = 1; m <= j; m++)
					{
					System.out.print("* ");
					}
			}
			else
			{
					System.out.print("* ");
					for (int n = 3; n <= j; n++)
					{
						System.out.print("  ");
					}
					System.out.print("* ");
			}
			System.out.println();
		}
	}
}
