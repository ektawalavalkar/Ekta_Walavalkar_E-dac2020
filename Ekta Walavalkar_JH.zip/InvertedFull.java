public class InvertedFull
{
    
    public static void main(String args[])
    {
     
        for(int i=6;i>=1;i--)
        {
            for(int j=6;j>=1;j--)
            {
                if(i>=j)
                {  
                    System.out.print(" *");//space after star
                }
                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
