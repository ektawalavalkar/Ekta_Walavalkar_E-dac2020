
public class Pyramid3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int j = 1; j <= 9; j++)// row
		{
			for (int m = 9; m > j; m--)// space
			{
				System.out.print(" ");

			}
			for (int i = 1; i <= j; i++)// col
			{
				System.out.print(" "+"*");
			}

			System.out.println();
		}
	}

}
