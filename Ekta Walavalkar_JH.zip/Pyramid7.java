public class Pyramid7
{
    
    public static void main(String args[])
    {
     
        for(int i=9;i>=1;i--)//row
        {
            for(int j=9;j>=1;j--)//col
            {
                if(i>=j)
                {  
                    System.out.print(i+" ");
                }
                else
                {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
