public class Half {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int j = 1; j <= 6; j++) //row
		{
			for (int i=1; i<= j; i++) //col
			{
			
				System.out.print("* ");
			}
				
			
			System.out.println();                     
		}
	}

}
