public class FullPyramid {
	public static void main(String args[]) {

		for (int j = 1; j <= 6; j++)// row
		{
			for (int i = 6; i >= 1; i--)// col
			{
				if (j >= i) {
					System.out.print("* ");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}
