
public class HollowInvertedHalf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int k = 1; k <= 6; k++) // 1st erow
		{
			System.out.print("* ");
		}
		System.out.println();

		for (int j = 5; j >= 1; j--)// row

		{
			for (int i = 1; i <= j; i++) //col
				{
				if (i == 1 || i == j) {
					System.out.print("* ");
				} else {
					System.out.print("  ");
				}
			}
			System.out.println();
		}

	}
}
