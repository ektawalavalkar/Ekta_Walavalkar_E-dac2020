class Employee
{
    static int empNo=0;
    int salery;
    static int totalSalery=0;
    
    Employee(int sal)
    {
        salery=sal;
        empNo++;
        totalSalery=totalSalery+salery;
    }
    
    static void display()
    {
        System.out.println("\nTotal Employees: "+empNo+"\nTotal Salery of all Employees: "+totalSalery);
    }
    
}

class Que5
{
    public static void main(String [] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter total Entries: ");
        int n=sc.nextInt();
        
        for(int i=0;i<n;i++)
        {
            System.out.print("Enter Salery of Employee "+(i+1)+": ");
            int s=sc.nextInt();
            Employee emp=new Employee(s);
        }
        
        Employee.display();
    }
}
