class MathOperation
{
    static int add(int a, int b)
    {
        return a+b;
    }
    
    static int subtract(int a, int b)
    {
        if(b>a)
            return b-a;
        else
        return a-b;
    }
    
    static int multiply(int a, int b)
    {
        return a*b;
    }
    
    static double power(int a, int b)
    {
        return Math.pow(a,b);
    }
}

class Que3
{
    public static void main(String [] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("a: ");
        int a=sc.nextInt();
        System.out.println("b: ");
        int b=sc.nextInt();
        
        System.out.println(MathOperation.add(a,b));
        System.out.println(MathOperation.subtract(a,b));
        System.out.println(MathOperation.multiply(a,b));
        System.out.println(MathOperation.power(a,b));
    }
}

