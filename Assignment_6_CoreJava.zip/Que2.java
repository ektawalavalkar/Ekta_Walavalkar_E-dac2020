class Circle
{
    int radius;
    float area;
    
    void init()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Radius: ");
        radius=sc.nextInt();
    }
    
    void calculateArea()
    {
        area=(float)(22/7.0f)*(radius*radius);
    }
    
    void display()
    {
        System.out.println("Area: "+area);
    }
}

class Que2
{
    public static void main(String [] args)
    {
        Circle obj=new Circle();
        obj.init();
        obj.calculateArea();
        obj.display();
    }
}

