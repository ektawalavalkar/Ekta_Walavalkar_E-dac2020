class One
{
	int roomArea;
	int hallArea;
	int price;
	
	public One() {
		this.roomArea=10;
		this.hallArea=10;
		this.price=1000;
	}
	
	public One(int roomArea, int hallArea, int price) {
	
		this.roomArea = roomArea;
		this.hallArea = hallArea;
		this.price = price;
	}
	
	void show() {
		System.out.println("Room Area := "+this.roomArea+"  Hall Area := "+this.hallArea+"  Price := "+this.price);
	}
	
}

class Two extends One{
	
	int room2Area;
	public Two(){
		super();
		this.room2Area=10;
	}
	public Two(int roomArea, int room2Area,int hallArea,int price) {
		super(roomArea,hallArea,price);
		this.room2Area = room2Area;
	}
	
	void show() {
		System.out.println("Room  1 Area := "+this.roomArea+"  Room 2 Area := "+this.room2Area+"  Hall Area := "+this.hallArea+"  Price := "+this.price);
	}
	
	 static void totalAmountOfFlates(Two ob1,Two ob2,Two ob3) {
		int total=ob1.price+ob2.price+ob3.price	;
		System.out.println("Total Price is := "+total);
				}
}

public class ConstructionPro {

	public static void main(String[] args) {
		
		Two ob1=new Two(100,100,100,1000);
		Two ob2=new Two(200,200,200,2000);
		Two ob3=new Two(300,300,300,3000);
		
		ob1.show();
		ob2.show();
		ob3.show();
		
		Two.totalAmountOfFlates(ob1, ob2, ob3);
	}
}
