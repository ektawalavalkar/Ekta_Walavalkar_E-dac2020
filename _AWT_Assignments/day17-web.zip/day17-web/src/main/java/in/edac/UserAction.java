package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


 
	@RestController
	@RequestMapping("/")
	public class UserAction {
		
		@GetMapping("/")
		public String sayHi() {
			 return "Hello World";
		}
		@GetMapping("/1")
		public String sayHello() {
			 return "Hello Hello";
		}
		@GetMapping("/2")
		public String sayAgain(String title) {
			 return "Hello Hello Again " + title;
		}
		@GetMapping("/3")
		public String sayAgain(String username,String password) {
			 return username + " " + password + " ";
		}
}
