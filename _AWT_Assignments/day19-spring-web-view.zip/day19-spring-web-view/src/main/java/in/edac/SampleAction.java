package in.edac;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/sample")
public class SampleAction {

	/*
	 * http://localhost:8080/sample/home-view
	 * 
	 */
	@GetMapping("/home-view")
	public String homeView() {

		/*
		 * we write its like as: request.getRequestDispatcher("/views/home.jsp").forward(request, response);
		 * 
		 * instead of that we can write it as retrun "home";
		 */
		// it inside src-main-webapp:: /views/home.jsp
		return "home";
	}
	/*
	 * http://localhost:8080/sample/home-View-V1
	 * */
	@GetMapping("/home-View-V1")
	public ModelAndView homeViewV1() {
		//return "register";
		//instead of write like above:: we write it as below
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		return mv;
		
	}
	/*
	 * http://localhost:8080/sample/home-View-V2
	 * */
	@GetMapping("/home-View-V2")
	public ModelAndView homeView2() {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		//data 
		String title = "Hello Mumbai";
		mv.addObject("title", title);
		
		return mv;
	}
	/**
	 * http://localhost:8080/sample/home-view-v3
	 * @return
	 */
	@GetMapping("/home-view-v3")
	public ModelAndView homeView3() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		// data 
		String title = "Hello Mumbai";
		mv.addObject("title", title);
		
		List<String> cityList = Arrays.asList("Delhi", "Kolkata", "Mumbai", "Chennai");
		mv.addObject("cityList", cityList);
		
		return mv;
	}
	/*
	 * http://localhost:8080/sample/home-View-V4
	 * */
	@GetMapping("/home-View-V4")
	public ModelAndView homeView4() {
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		//data 
		String title = "Hello Mumbai";
		mv.addObject("title", title);
		
		List<String> cityList = Arrays.asList("Delhi","Kolkata","Mumbai","Pune");
		mv.addObject("cityList", cityList);
		
		List<User> userList = new ArrayList<User>();
	    userList.add(new User(1,"virat","@!#@!","virat@gmail.com"));
	    userList.add(new User(2,"rohit","@!#@!","rohit@gmail.com"));
		
	    mv.addObject("userList", userList);
		
		
		return mv;
	}
	/*
	 * http://localhost:8080/sample/home-View-V5
	 * */
	@GetMapping("/home-View-V5")
	public ModelAndView homeView5(String q) {
		
		ModelAndView mv = new ModelAndView("home");
		//mv.setViewName("home");
		
		if("1".equals(q)) {
			mv.setViewName("hello");
		}
		//data 
		String title = "Hello Mumbai" +q;
		mv.addObject("title", title);
		
		List<String> cityList = Arrays.asList("Delhi","Kolkata","Mumbai","Pune");
		mv.addObject("cityList", cityList);
		
		List<User> userList = new ArrayList<User>();
	    userList.add(new User(1,"virat","@!#@!","virat@gmail.com"));
	    userList.add(new User(2,"rohit","@!#@!","rohit@gmail.com"));
		
	    mv.addObject("userList", userList);
		
		
		return mv;
	}
}
