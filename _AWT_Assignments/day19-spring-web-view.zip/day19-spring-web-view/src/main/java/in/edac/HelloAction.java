package in.edac;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
/*
 * import org.springframework.web.bind.annotation.RestController;

 Its a program is a restful nature in program
 using @RestController.
 
@RequestMapping("/hello")
public class HelloAction {

	
	
	  *http://localhost:8080/hello/
	 *@return
	 *
	@GetMapping("/")
	public String sayHello() {
		
		return "Hello";
	}
}
 * 
 * */

@Controller
@RequestMapping("/hello")
public class HelloAction {

	/*
	 * http://localhost:8080/hello/
	 * 
	 * @return
	 */
	@GetMapping("/")
	public String sayHello() {
		// ..do someWork here
		// return "/views/hello.jsp";
		return "hello";
	}

	/*
	 * http://localhost:8080/hello/1
	 * */
	@GetMapping("/1")
	public String sayHi() {
		// /views/hi.jsp
		return "hi";
	}
	
}
