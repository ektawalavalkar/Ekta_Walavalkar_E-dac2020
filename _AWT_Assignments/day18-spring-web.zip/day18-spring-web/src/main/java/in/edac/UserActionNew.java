package in.edac;

import java.util.List;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserActionNew {

	/*
	 * http://localhost:8080/user/
	 */
	@GetMapping("/")
	public List<User> getUsers() {
		List<User> list = new ArrayList<User>();

		User user1 = new User(1, "Chennai", "!@#@!", "mumbai@gmail.com", "455788");
		User user2 = new User(2, "Pune", "!@#@!", "mumbai@gmail.com", "455788");

		list.add(user1);
		list.add(user2);
		return list;
	}

	/*
	 * hard coded value: http://localhost:8080/user/1 http://localhost:8080/user/2
	 * ... http://localhost:8080/user/n ============ not hard coded:
	 * http://localhost:8080/user/{id}:: this is user for different user,dynamic
	 * using {}
	 * 
	 * @param id
	 * 
	 * @return
	 */
	@GetMapping("/{id}")
	public User getSingleUser(@PathVariable int id) {

		User user = new User(id, "mumbai", "!@#@!", "mumbai@gmail.com", "455788");
		return user;
	}

	/*
	 * 
	 * http://localhost:8080/user/
	 * 
	 * @return
	 */
	/*
	 * @PostMapping("/") public String createUSer(String name,String email,String
	 * mobile) { //create object in database return name + email +mobile; } you dont
	 * have to write like above, instead of this we can also write it as a below..
	 */
	@PostMapping("/")
	public User createUSer(User user) {
		// create object in database
		return user;
	}

	/*
	 * http://localhost:8080/user/1
	 * http://localhost:8080/user/2
	 * http://localhost:8080/user/3
	 * ...
	 * http://localhost:8080/user/n
	 * 
	 * 
	 */

	@PutMapping("/{id}")
	public User updateUser(@PathVariable int id, User user) {
		// ...update the record in datbase
		return user;

	}
	/**
	 * http://localhost:8080/user/1
	 * http://localhost:8080/user/2
	 * http://localhost:8080/user/3
	 * ...
	 * http://localhost:8080/user/n
	 * 
	 * @param id
	 */
	@DeleteMapping("/{id}")
	public int deleteUser(@PathVariable int id) {
		return id;
	}
}
