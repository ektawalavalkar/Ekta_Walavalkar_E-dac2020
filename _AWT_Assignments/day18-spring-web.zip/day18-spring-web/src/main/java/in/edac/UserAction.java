package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class UserAction {

	/*
	 * http://localhost:8080/
	 * 
	 * @return
	 */
	@GetMapping("/")
	public String helloWorld() {
		return "Revision";
	}

	/*
	 * http://localhost:8080/1
	 * 
	 * @return
	 */

	@GetMapping("/1")
	private String helloWorldV1() {
		return "Revision V1";
	}

	/*
	 * http://localhost:8080/2
	 * 
	 * @return
	 */
	@GetMapping("/2")
	private String helloWorldV2() {
		return "Revision V2";
	}
}
