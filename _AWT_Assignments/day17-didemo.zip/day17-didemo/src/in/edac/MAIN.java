package in.edac;

public class MAIN {
	// @Autowired
	private Engine e;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	/*	
	 //1
     User user = new User();
     System.out.println(user.getId());
     System.out.println(user.getName());
     
     //2 initialzed the member at the time of the construction
     User user1 = new User(1,"mumbai","mumbai@gmail.com","45698");
     System.out.println(user1.getId());
     System.out.println(user1.getName());
     System.out.println(user1.getAddress());
     
     //3
     User user2 = new User();
     System.out.println(user2.getId());
     System.out.println(user2.getName());
     
     //udating object using set method
     
     user2.setId(100);
     user2.setName("Delhi");
     System.out.println(user2.getId());
     System.out.println(user2.getName());
     
     Address a1 = new Address("kharghr","MH");
     User user21 = new User(2,"delhi","delhi@gmail.com","45787",a1);
     System.out.println(user21.getId());
     System.out.println(user21.getName());
     System.out.println(user21.getAddress());
     System.out.println(user21.getAddress().getCity());
     */
	
		
		public void testEngine() {
			// COMPLEX OBJECT :: DISEL/PETROL/ELECTRIC/BATTERY/SOLAR
			// Engine e = new Engine("SOLAR");
					
			Car car = new Car(1, "AAA", "BLACK", e);
			System.out.println(car);
		}
	
	

}
