package in.edac;

public class Engine {
	private String engineType;

	public Engine(String engineType) {
		super();
		this.engineType = engineType;
	}

}