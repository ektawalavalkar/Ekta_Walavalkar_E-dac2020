package in.edac;

public class Car {
	private int id;
	private String modelNumber;
	private String color;
	
	private Engine engine;
	/*private Suspension suspension;
	private Cooling cooling;
	private String string;
	private Navigation navigation;*/
/*
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getModelNumber() {
		return modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}*/

	/*private Suspension suspension;
	private Cooling cooling;
	private Streing stering;
	private Navigation navigation;*/
	
	
	public Car(int id, String modelNumber, String color, Engine engine) {
		super();
		this.id = id;
		this.modelNumber = modelNumber;
		this.color = color;
		this.engine = engine;
	}
	
}
