import java.util.Scanner;

public class Circle {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the radius:");
		double r = sc.nextDouble();
		double area = Math.PI * (r * r);
		System.out.println("Area of circle is: " + area);
		double circumference = Math.PI * 2 * r;
		System.out.println("Circumference of the circle:" + circumference);
	}

}
