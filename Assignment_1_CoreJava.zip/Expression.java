import java.util.Scanner;

public class Expression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number x :");
		int x = sc.nextInt();
		int y = ((x * x) + (3 * x) - 7);
		System.out.println("y:" + y);
		y = x++ + ++x;
		System.out.println("x: " + x + " y:" + y);
		int z = x++ - --y - --x + x++;
		System.out.println("x: " + x + " y:" + y + " z: " + z);
		System.out.print("Enter number x :");
		boolean X = sc.nextBoolean();
		System.out.print("Enter number y :");
		boolean Y = sc.nextBoolean();
		boolean Z = ((X && Y) || !(X || Y));
		System.out.println("Z:" + Z);

	}

}
