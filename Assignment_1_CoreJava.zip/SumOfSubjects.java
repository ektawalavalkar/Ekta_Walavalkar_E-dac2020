import java.util.Scanner;

public class SumOfSubjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int c, SQL, java, python, HTML;
		int total, percentage;
		// Scanner sc =new Scanner(System.in);
		// System.out.println("Enter marks of 5 subjects:");
		System.out.print("Enter marks of C :");
		c = sc.nextInt();
		System.out.print("Enter marks of SQL :");
		SQL = sc.nextInt();
		System.out.print("Enter marks of JAVA :");
		java = sc.nextInt();
		System.out.print("Enter marks of PYTHON:");
		python = sc.nextInt();
		System.out.print("Enter marks of HTML:");
		HTML = sc.nextInt();
		total = c + SQL + java + python + HTML;
		percentage = (total / 500) * 100;

		System.out.println("Total marks:" + total);
		System.out.println("Percentage:" + percentage + "%");

	}

}
