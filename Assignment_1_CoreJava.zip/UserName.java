import java.util.Scanner;

public class UserName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter User Name:");
		String s = sc.nextLine();
		System.out.println("Welcome " + s);
	}

}
