import java.util.Scanner;

public class eligibleOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age:");
		int age = sc.nextInt();
		System.out.println("Enter gender: M/F");
		int gender = sc.next().charAt(0);
		if (gender == 'F') {
			if (age >= 18) {
				System.out.println("You are eligible for Marriage");
			} else {
				System.out.println("You are Not eligible for Marriage");
			}
		}

		if (gender == 'M') {
			if (age >= 20) {
				System.out.println("You are eligible for Marriage");
			} else {
				System.out.println("You are Not eligible for Marriage");
			}
		}
	}

}
