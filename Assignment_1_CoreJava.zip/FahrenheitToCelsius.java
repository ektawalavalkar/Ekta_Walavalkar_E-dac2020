import java.util.Scanner;

public class FahrenheitToCelsius {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Fahrenheit Temperature:");
		double f = sc.nextDouble();
		double C = 5 * (f - 32) / 9;
		System.out.println("From Fahrenheit to Celsius: " + C);
	}

}
