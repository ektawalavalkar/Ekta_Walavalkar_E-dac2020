
public class Student {
	static int rollno = 100;

	public static void main(String[] args) {
		int rollno = 101;
		System.out.println("roll no= " + Student.rollno);
		System.out.println("roll no= " + rollno);
	}

}
