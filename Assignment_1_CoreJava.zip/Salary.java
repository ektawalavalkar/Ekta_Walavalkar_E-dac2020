import java.util.Scanner;

public class Salary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float da, hra;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter basic salary:");
		float bs = sc.nextFloat();
		if (bs < 1500) {
			hra = bs * 10 / 100;
			da = bs * 90 / 100;
		} else {
			hra = 500;
			da = bs * 98 / 100;
		}
		float gs = bs + hra + da;
		System.out.println("Enter HRA:" + hra);
		System.out.println("Enter DA:" + da);
		System.out.println("Enter gross salary:" + gs);
	}

}
