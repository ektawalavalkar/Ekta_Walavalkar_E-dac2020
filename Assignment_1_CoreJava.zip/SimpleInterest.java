import java.util.Scanner;

public class SimpleInterest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter principle amount: ");
		float p = sc.nextFloat();
		System.out.println("Enter rate of Interest: ");
		float n = sc.nextFloat();
		System.out.println("Enter time:");
		float r = sc.nextFloat();
		float SI = ((p * n * r) / 100);
		System.out.println("Simple Interest:" + SI);

	}

}
