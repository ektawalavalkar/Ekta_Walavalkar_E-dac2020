import java.util.Scanner;

public class GreatestNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first number:");
		int x = sc.nextInt();
		System.out.println("Enter second number:");
		int y = sc.nextInt();
		System.out.println("Enter third number:");
		int z = sc.nextInt();
		int large = x > y ? x : y;
		int largest = z > large ? z : large;
		System.out.println("The largest number is: " + largest);

	}

}
