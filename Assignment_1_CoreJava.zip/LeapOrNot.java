import java.util.Scanner;

public class LeapOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Year:");
		int y = sc.nextInt();
		if (y % 4 == 0) {
			System.out.println("Leap year");
		} else {
			System.out.println("Not a Leap year");
		}
	}

}
