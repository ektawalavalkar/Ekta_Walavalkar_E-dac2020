import java.util.Scanner;

public class ByteVariable {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Number 1: ");
		byte b1;
		b1 = sc.nextByte();
		System.out.println("Enter Number 2: ");
		byte b2;
		b2 = sc.nextByte();
		byte add = (byte) (b1 + b2);
		System.out.print("Additon: " + add);
	}

}
