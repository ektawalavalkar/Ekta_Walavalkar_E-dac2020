import java.util.Scanner;

public class ConvertDays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int year, week, days;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of days:");
		int num_days = sc.nextInt();
		year = num_days / 365;
		week = (num_days % 365) / 7;
		days = (num_days % 365) % 7;

		System.out.println("years = " + year);
		System.out.println("weeks = " + week);
		System.out.println("days = " + days);
	}

}
