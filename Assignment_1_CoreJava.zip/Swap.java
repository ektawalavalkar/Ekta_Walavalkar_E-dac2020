import java.util.Scanner;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of x and y:");
		int x = sc.nextInt();
		int y = sc.nextInt();
		System.out.println("Before Swap:" + x + "  " + y);
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println("After swapping: " + x + "  " + y);
	}

}
